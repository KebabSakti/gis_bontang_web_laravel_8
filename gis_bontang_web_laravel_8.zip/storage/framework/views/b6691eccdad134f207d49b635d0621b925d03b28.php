

<?php $__env->startSection('content'); ?>
    
<main>
    <div class="container box_1170 pt-30 pb-100">
        <h3 class="text-heading">Agenda</h3><hr>
        <div>
            <table class="table table-bordered table-hover datatable" style="font-size: 0.6em;">
                <thead>
                    <tr>
                        <th>Penanggung Jawab</th>
                        <th>Lokasi Acara</th>
                        <th>Agenda</th>
                        <th>Tanggal Post</th>
                        <th>Tanggal Update</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</main>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function() {
    var table;

    function loadData() {
        table = $('.datatable').DataTable({
            processing: true,
            serverSide: true,
            order: [[4, "desc"]],
            ajax: $.fn.dataTable.pipeline({
                url: '<?php echo route('publicpagecontroller.agenda'); ?>',
                method: 'POST',
                data: function(d) {
                    d._token = '<?php echo csrf_token(); ?>';
                },
                pages: 5,
            })
        });
    }
    
    loadData();

    table.on('search.dt', function() {
        search = table.search();
        $('input[name="search"]').val(search);
    });
});

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('public.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gis_bontang_web_laravel_8\resources\views/public/agenda.blade.php ENDPATH**/ ?>