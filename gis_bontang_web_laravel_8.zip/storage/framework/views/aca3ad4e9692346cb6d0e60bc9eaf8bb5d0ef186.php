

<?php $__env->startSection('content'); ?>

<main>
    <!-- About US Start -->
    <div class="about-area pt-30">
        <div class="container">
               <div class="row">
                    <div class="col-lg-8">
                        <!-- Trending Tittle -->
                        <div class="about-right mb-90">
                            <div class="about-img">
                                <img src="<?php echo e(asset('foto/'.$newsDetail->image)); ?>" alt="" class="lazy" data-src="<?php echo e(asset('foto/'.$newsDetail->image)); ?>">
                            </div>
                            <div class="section-tittle mb-30 pt-30">
                                <h3><?php echo e($newsDetail->title); ?></h3>
                            </div>
                            <div class="about-prea">
                                <p class="about-pera1 mb-25 text-justify">
                                    <?php echo nl2br(e($newsDetail->content), false); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="blog_right_sidebar">
                            <aside class="single_sidebar_widget popular_post_widget">
                                <h3 class="widget_title">Berita Terkait</h3>
                                <?php $__currentLoopData = $relatedNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="media post_item">
                                        <img src="<?php echo e(asset('foto/'.$item->image)); ?>" alt="" class="lazy" data-src="<?php echo e('foto/'.$item->image); ?>" width="100">
                                        <div class="media-body">
                                            <a href="<?php echo e(route('publicpagecontroller.beritadetail', ['id'=>$item->id])); ?>">
                                                <h3><?php echo e(Str::limit($item->title, 20)); ?></h3>
                                            </a>
                                            <p><?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->created_at, 'Asia/Kuala_Lumpur')->format('F d, Y')); ?></p>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </aside>
                        </div>
                    </div>
               </div>
        </div>
    </div>
    <!-- About US End -->
</main>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gis_bontang_web_laravel_8\resources\views/public/berita_detail.blade.php ENDPATH**/ ?>