<form method="POST" action="<?php echo e(route('option.update', $data->id)); ?>" data-parsley-validate class="form-horizontal form-label-left">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="item form-group">
        <label class="col-form-label col-md-3 col-sm-3 label-align">Tag</label>
        <div class="col-md-6 col-sm-6 ">
            <input type="text" class="form-control " value="<?php echo e($data->tag); ?>" readonly>
        </div>
    </div>
    <div class="item form-group">
        <label class="col-form-label col-md-3 col-sm-3 label-align">Nama</label>
        <div class="col-md-6 col-sm-6 ">
            <input type="text" class="form-control " name="name" value="<?php echo e($data->name); ?>" required>
        </div>
    </div>
    <div class="item form-group">
        <label class="col-form-label col-md-3 col-sm-3 label-align">Status</label>
        <div class="col-md-6 col-sm-6 ">
            <select name="active" class="form-control">
                <?php
                    $status = [
                        'Aktif' => 1,
                        'Non Aktif' => 0,
                    ];
                ?>
                <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $c = $data->active == $value ? 'selected':'';
                    ?>
                    <option value="<?php echo e($value); ?>" <?php echo e($c); ?>><?php echo e($key); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="item form-group">
        <div class="col-md-6 col-sm-6 offset-md-3">
            <button type="submit" class="btn btn-success">Submit</button>
        </div>
    </div>

</form><?php /**PATH C:\xampp\htdocs\gis_bontang_web_laravel_8\resources\views/admin/option/edit.blade.php ENDPATH**/ ?>