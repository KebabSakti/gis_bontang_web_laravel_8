<form method="POST" action="<?php echo e(route('agenda.update', $data->id)); ?>" data-parsley-validate class="form-horizontal form-label-left">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="item form-group">
        <label class="col-form-label col-md-3 col-sm-3 label-align">Penanggung Jawab</label>
        <div class="col-md-6 col-sm-6 ">
            <input type="text" class="form-control" name="author" value="<?php echo e($data->author); ?>" required>
        </div>
    </div>
    <div class="item form-group">
        <label class="col-form-label col-md-3 col-sm-3 label-align">Lokasi Acara</label>
        <div class="col-md-6 col-sm-6 ">
            <textarea name="location" class="form-control" cols="30" rows="5" required><?php echo e($data->location); ?></textarea>
        </div>
    </div>
    <div class="item form-group">
        <label class="col-form-label col-md-3 col-sm-3 label-align">Agenda</label>
        <div class="col-md-6 col-sm-6 ">
            <textarea name="agenda" class="form-control" cols="30" rows="10" required><?php echo e($data->agenda); ?></textarea>
        </div>
    </div>
    <div class="item form-group">
        <div class="col-md-6 col-sm-6 offset-md-3">
            <button type="submit" class="btn btn-success">Submit</button>
        </div>
    </div>
</form><?php /**PATH C:\xampp\htdocs\gis_bontang_web_laravel_8\resources\views/admin/agenda/edit.blade.php ENDPATH**/ ?>