<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/img/logo/logo-bontang-only.png')); ?>">
    <title>Admin Login</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/fontawesome-all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <style>
        html, body {
            height: 100%;
            background-color: #efefef;
        }
    </style>

</head>
<body>
    <div class="container h-100">
        <div class="row h-100 justify-content-center align-items-center">
          <div class="col-lg-6 col-md-12 ml-2 mr-2">
            <div class="row">
                <div class="col-12">
                    <?php if(session('message')): ?>
                        <div class="alert alert-info alert-dismissible fade show" role="alert">
                        <?php echo e(session('message')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-12 card p-4">
                    <form method="POST" accept="<?php echo e(route('auth.admin.loginsubmit')); ?>">
                        <?php echo csrf_field(); ?>
                        <div>
                            <img src="<?php echo e(asset('assets/img/logo/logo-bontang.png')); ?>">
                        </div>
                        <hr>
                        <div class="form-group">
                          <label>Email</label>
                          <input type="text" class="single-input" id="formGroupExampleInput" placeholder="Email" name="email" required>
                        </div>
                        <div class="form-group">
                          <label>Password</label>
                          <input type="password" class="single-input" id="formGroupExampleInput2" placeholder="Password" name="password" required>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="genric-btn info radius">Login</button>
                        </div>
                    </form>     
                </div>    
            </div>    
          </div>  
        </div>
    </div>


    <script src="<?php echo e(asset('assets/js/vendor/jquery-1.12.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\gis_bontang_web_laravel_8\resources\views/admin/login.blade.php ENDPATH**/ ?>