

<?php $__env->startSection('content'); ?>
    
<main>
    <div class="container box_1170 pt-30 pb-100">
        <h3 class="text-heading">Profil</h3><hr>
        <div>
            <p class="text-justify">
                <?php echo e($profile->caption); ?>

            </p>
        </div>
        <h3 class="text-heading mt-100">Visi & Misi</h3><hr>
        <div>
            <p class="text-justify">
                <?php echo e($vision->caption); ?>

            </p>
        </div>
    </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gis_bontang_web_laravel_8\resources\views/public/profile.blade.php ENDPATH**/ ?>