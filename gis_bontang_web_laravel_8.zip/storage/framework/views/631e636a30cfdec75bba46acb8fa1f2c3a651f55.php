

<?php $__env->startSection('content'); ?>

  <div class="right_col" role="main">
    <div class="">
      <div class="page-title">
        <div class="title_left">
          <h3>Beranda</h3>
          <br>
        </div>
      </div>

      <div class="clearfix"></div>

      <div class="row">
        <div class="col-md-12 col-sm-12  ">
          <div class="x_panel">
            
            <div class="x_content">
                Selamat Datang <br>
                Anda login sebagai, <strong><?php echo e(Auth::guard('admin')->user()->name); ?></strong> <br>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gis_bontang_web_laravel_8\resources\views/admin/beranda.blade.php ENDPATH**/ ?>