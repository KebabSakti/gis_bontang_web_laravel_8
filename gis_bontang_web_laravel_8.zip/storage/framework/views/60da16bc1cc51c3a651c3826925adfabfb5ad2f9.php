<form method="POST" action="<?php echo e(route('area.update', $data->id)); ?>" data-parsley-validate class="form-horizontal form-label-left">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="item form-group">
        <label class="col-form-label col-md-3 col-sm-3 label-align">Kode</label>
        <div class="col-md-6 col-sm-6 ">
            <input type="text" class="form-control" value="<?php echo e($data->code); ?>" readonly>
        </div>
    </div>
    <div class="item form-group">
        <label class="col-form-label col-md-3 col-sm-3 label-align">Tag</label>
        <div class="col-md-6 col-sm-6 ">
            <input type="text" class="form-control " value="<?php echo e($data->tag); ?>" readonly>
        </div>
    </div>
    <div class="item form-group">
        <label class="col-form-label col-md-3 col-sm-3 label-align">Nama</label>
        <div class="col-md-6 col-sm-6 ">
            <input type="text" class="form-control " name="name" value="<?php echo e($data->name); ?>" required>
        </div>
    </div>
    <div class="item form-group">
        <div class="col-md-6 col-sm-6 offset-md-3">
            <button type="submit" class="btn btn-success">Submit</button>
        </div>
    </div>

</form><?php /**PATH C:\xampp\htdocs\gis_bontang_web_laravel_8\resources\views/admin/area/edit.blade.php ENDPATH**/ ?>