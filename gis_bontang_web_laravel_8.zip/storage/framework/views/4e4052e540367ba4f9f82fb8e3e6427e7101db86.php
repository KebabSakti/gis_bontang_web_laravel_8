

<?php $__env->startSection('content'); ?>
<main>
    <div class="container box_1170 pt-30 pb-100">
        <h3 class="text-heading">Gallery</h3><hr>
        <div>
            <div class="grid">
                <div class="grid-sizer"></div>
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="grid-item">
                        <a href="<?php echo e(asset('foto/'.$item->image)); ?>" class="img-pop-up">
                            
                            <img src="<?php echo e(asset('foto/'.$item->image)); ?>">
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <p class="text-center">
                <?php echo e($images->links()); ?>

            </p>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gis_bontang_web_laravel_8\resources\views/public/gallery.blade.php ENDPATH**/ ?>