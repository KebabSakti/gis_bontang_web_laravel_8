

<?php $__env->startSection('content'); ?>

    <!--================Blog Area =================-->
    <section class="blog_area section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mb-5 mb-lg-0">
                    <div class="blog_left_sidebar">
                        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="blog_item">
                                <div class="blog_item_img">
                                    <img class="card-img rounded-0" src="<?php echo e(asset('foto/'.$item->image)); ?>" alt="">
                                    <a href="<?php echo e(route('publicpagecontroller.beritadetail', ['id'=>$item->id])); ?>" class="blog_item_date">
                                        <h3><?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->created_at, 'Asia/Kuala_Lumpur')->format('d')); ?></h3>
                                        <p><?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->created_at, 'Asia/Kuala_Lumpur')->format('M')); ?></p>
                                    </a>
                                </div>

                                <div class="blog_details">
                                    <a class="d-inline-block" href="<?php echo e(route('publicpagecontroller.beritadetail', ['id'=>$item->id])); ?>">
                                        <h2><?php echo e($item->title); ?></h2>
                                    </a>
                                    <p>
                                        <?php echo e(Str::limit($item->content, 300)); ?>

                                    </p>
                                </div>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php echo e($news->links()); ?>


                        
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="blog_right_sidebar">
                        <aside class="single_sidebar_widget popular_post_widget">
                            <h3 class="widget_title">Berita Terbaru</h3>
                            <?php $__currentLoopData = $newNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="media post_item">
                                    <img src="<?php echo e(asset('foto/'.$item->image)); ?>" alt="" class="lazy" data-src="<?php echo e(asset('foto/'.$item->image)); ?>" width="100">
                                    <div class="media-body">
                                        <a href="<?php echo e(route('publicpagecontroller.beritadetail', ['id'=>$item->id])); ?>">
                                            <h3><?php echo e(Str::limit($item->title, 20)); ?></h3>
                                        </a>
                                        <p><?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->created_at, 'Asia/Kuala_Lumpur')->format('F d, Y')); ?></p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </aside>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--================Blog Area =================-->
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gis_bontang_web_laravel_8\resources\views/public/berita.blade.php ENDPATH**/ ?>