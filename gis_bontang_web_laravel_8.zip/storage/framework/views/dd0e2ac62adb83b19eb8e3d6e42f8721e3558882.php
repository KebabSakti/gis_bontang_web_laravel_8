

<?php $__env->startSection('content'); ?>

<main>
<!-- Trending Area Start -->
<div class="trending-area fix">
    <div class="container">
        <div class="trending-main pt-30">
            <!-- Trending Tittle -->
            <div class="row">
                <div class="col-lg-8">
                    <!-- Trending Top -->
                    <div class="trending-top mb-30">
                        <div class="trend-top-img">
                            <img src="<?php echo e(asset('foto/'.$trendingTop[0]->image)); ?>" alt="" class="lazy" data-src="<?php echo e(asset('foto/'.$trendingTop[0]->image)); ?>">
                            <div class="trend-top-cap">
                                <span><?php echo e($trendingTop[0]->tag); ?></span>
                                <h2><a href="<?php echo e(route('publicpagecontroller.beritadetail', ['id'=>$trendingTop[0]->id])); ?>"><?php echo e(Str::limit($trendingTop[0]->title, 100)); ?></a></h2>
                            </div>
                        </div>
                    </div>
                    <!-- Trending Bottom -->
                    <div class="trending-bottom">
                        <div class="row">
                            <?php $__currentLoopData = $trendingBottom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4">
                                    <div class="single-bottom mb-35">
                                        <div class="trend-bottom-img mb-30">
                                            <img src="<?php echo e(asset('foto/'.$item->image)); ?>" alt="" class="lazy" data-src="<?php echo e(asset('foto/'.$item->image)); ?>">
                                        </div>
                                        <div class="trend-bottom-cap">
                                            <span class="color1"><?php echo e($item->tag); ?></span>
                                            <h4><a href="<?php echo e(route('publicpagecontroller.beritadetail', ['id'=>$item->id])); ?>"><?php echo e(Str::limit($item->title, 100)); ?></a></h4>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <!-- Right content -->
                <div class="col-lg-4">
                    <?php $__currentLoopData = $rightNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="trand-right-single d-flex">
                            <div class="trand-right-img">
                                <img src="<?php echo e(asset('foto/'.$item->image)); ?>" width="100" alt="" class="lazy" data-src="<?php echo e(asset('foto/'.$item->image)); ?>">
                            </div>
                            <div class="trand-right-cap">
                                <span class="color1"><?php echo e($item->tag); ?></span>
                                <h4><a href="<?php echo e(route('publicpagecontroller.beritadetail', ['id'=>$item->id])); ?>"><?php echo e(Str::limit($item->title, 100)); ?></a></h4>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Trending Area End -->
<!-- Start Youtube -->

<!-- End Start youtube -->

<!--   Weekly2-News start -->
<div class="trending-area fix mt-30 mb-30">
    <div class="container">
        <div class="weekly2-wrapper">
            <!-- section Tittle -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-tittle mb-30">
                        <h3>Gallery</h3>
                    </div>
                </div>
            </div>
            <div class="grid">
                <div class="grid-sizer"></div>
                <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="grid-item">
                        <a href="<?php echo e(asset('foto/'.$item->image)); ?>" class="img-pop-up">
                            
                            <img src="<?php echo e(asset('foto/'.$item->image)); ?>">
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>           
<!-- End Weekly-News -->

<!--   Weekly2-News start -->
<div class="weekly2-news-area  weekly2-pading gray-bg">
    <div class="container">
        <div class="weekly2-wrapper">
            <!-- section Tittle -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-tittle mb-30">
                        <h3>Berita Terbaru</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="weekly2-news-active dot-style d-flex dot-style">
                        <?php $__currentLoopData = $newNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="weekly2-single">
                                <div class="weekly2-img">
                                    <img src="<?php echo e(asset('foto/'.$item->image)); ?>" alt="" class="lazy" data-src="<?php echo e(asset('foto/'.$item->image)); ?>">
                                </div>
                                <div class="weekly2-caption">
                                    <span class="color1"><?php echo e($item->tag); ?></span>
                                    <p><?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->created_at, 'Asia/Kuala_Lumpur')->format('d M Y')); ?></p>
                                    <h4><a href="<?php echo e(route('publicpagecontroller.beritadetail', ['id'=>$item->id])); ?>"><?php echo e(Str::limit($item->title, 100)); ?></a></h4>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>           
<!-- End Weekly-News -->

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gis_bontang_web_laravel_8\resources\views/public/beranda.blade.php ENDPATH**/ ?>