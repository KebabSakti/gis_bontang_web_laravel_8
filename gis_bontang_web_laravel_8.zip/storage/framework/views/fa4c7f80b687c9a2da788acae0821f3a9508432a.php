<form method="POST" action="" data-parsley-validate class="form-horizontal form-label-left">
    <div class="item form-group">
        <label class="col-form-label col-md-3 col-sm-3 label-align">Nama</label>
        <div class="col-md-6 col-sm-6 ">
            <input type="text" class="form-control " name="title" value="<?php echo e($data->name); ?>" readonly>
        </div>
    </div>
    <div class="item form-group">
        <label class="col-form-label col-md-3 col-sm-3 label-align">No. Telp</label>
        <div class="col-md-6 col-sm-6 ">
            <input type="text" class="form-control " name="title" value="<?php echo e($data->phone); ?>" readonly>
        </div>
    </div>
    <div class="item form-group">
        <label class="col-form-label col-md-3 col-sm-3 label-align">Subjek</label>
        <div class="col-md-6 col-sm-6 ">
            <input type="text" class="form-control " name="title" value="<?php echo e($data->subject); ?>" readonly>
        </div>
    </div>
    <div class="item form-group">
        <label class="col-form-label col-md-3 col-sm-3 label-align">Pesan</label>
        <div class="col-md-6 col-sm-6 ">
            <textarea name="caption" class="form-control" cols="30" rows="10" readonly><?php echo e($data->messages); ?></textarea>
        </div>
    </div>
</form><?php /**PATH C:\xampp\htdocs\gis_bontang_web_laravel_8\resources\views/admin/contact/show.blade.php ENDPATH**/ ?>