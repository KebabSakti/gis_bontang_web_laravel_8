<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/img/logo/logo-bontang-only.png')); ?>">
    <title>Form Pendataan</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/fontawesome-all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <style>
        html, body {
            height: 100%;
            background-color: #efefef;
        }
        .foto {
            height: 0px;
            width: 0px;
            overflow: hidden;
            display: none;
        }
        .foto-trigger {
            cursor: pointer;
            font-size: 14px;
        }
    </style>

</head>
<body>
    <div class="container h-100">
        <div class="row h-100 justify-content-center align-items-center">
          <div class="col-lg-8 col-md-12 card pt-4 pb-4 m-2">
            <h4 class="text-center mb-4">Form Pendataan</h4>
            <?php if(session('message')): ?>
                <div class="alert alert-info alert-dismissible fade show" role="alert">
                <?php echo e(session('message')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
            <?php endif; ?>
            <form id="validate-form" method="POST" action="<?php echo e(route('user.formsubmit')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="form_id" value="<?php echo e(App\CustomClass\IDGenerator::generate()); ?>">
                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->user_id); ?>">
                <input type="hidden" name="name" value="<?php echo e(Auth::user()->name); ?>">
                <div class="input-group-icon mt-10">
                    <div class="icon"><i class="fa fa-caret-right aria-hidden="true"></i></div>
                    <select name="kelurahan" class="form-control single-input" required>
                        <option value="">- Pilih Desa / Kelurahan -</option>
                        <?php $__currentLoopData = $areas->where('tag', 'kelurahan'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="input-group-icon mt-10">
                    <div class="icon"><i class="fa fa-caret-right aria-hidden="true"></i></div>
                    <select name="kecamatan" class="form-control single-input" required>
                        <option value=""> - Pilih Kecamatan - </option>
                        <?php $__currentLoopData = $areas->where('tag', 'kecamatan'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="input-group-icon mt-10">
                    <div class="icon"><i class="fa fa-caret-right aria-hidden="true"></i></div>
                    <select name="kabupaten" class="form-control single-input" required>
                        <option value=""> - Pilih Kabupaten / Kota - </option>
                        <?php $__currentLoopData = $areas->where('tag', 'kabupaten'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="input-group-icon mt-10">
                    <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                    <select name="provinsi" class="form-control single-input" required>
                        <option value=""> - Pilih Provinsi - </option>
                        <?php $__currentLoopData = $areas->where('tag', 'provinsi'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="input-group-icon mt-10">
                    <div class="icon"><i class="fa fa-images" aria-hidden="true"></i></div>
                    <input type="text" placeholder="Foto" class="single-input foto-trigger" readonly>
                    <input type="file" name="foto[]" class="foto" multiple>
                </div>
                <div class="mt-30" style="border-bottom: 0.5px solid #efefef;">
                    <h6>I. IDENTITAS PENGHUNI RUMAH</h6>
                </div>
                <div class="mt-10">
                    <input type="number" min="0" name="nomor_urut" placeholder="Nomor Urut" class="single-input" required>
                </div>
                <div class="mt-10">
                    <input type="text" name="nama_lengkap" placeholder="Nama Lengkap" class="single-input" required>
                </div>
                <div class="mt-10">
                    <input type="number" min="0" name="usia" placeholder="Usia (Tahun)" class="single-input" required>
                </div>
                <div class="input-group-icon mt-10">
                    <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                    <select name="pendidikan" class="form-control single-input" required>
                        <option value=""> - Pendidikan Terakhir - </option>
                        <?php $__currentLoopData = $options->where('tag', 'pendidikan')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="input-group-icon mt-10">
                    <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                    <select name="jk" class="form-control single-input" required>
                        <option value=""> - Jenis Kelamin - </option>
                        <?php $__currentLoopData = $options->where('tag', 'jk')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mt-10">
                    <input type="text" name="nik" placeholder="Nomor KTP (NIK)" class="single-input" required>
                </div>
                <div class="mt-10">
                    <input type="number" min="1" name="jumlah_kk" placeholder="Jumlah KK dalam 1 rumah" class="single-input" required>
                </div>
                <div class="mt-10">
                    <textarea name="alamat" placeholder="Alamat Lengkap" class="single-textarea" required></textarea>
                </div>
                <div class="input-group-icon mt-10">
                    <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                    <select name="pekerjaan" class="form-control single-input" required>
                        <option value=""> - Pekerjaan Utama - </option>
                        <?php $__currentLoopData = $options->where('tag', 'pekerjaan')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="input-group-icon mt-10">
                    <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                    <select name="penghasilan" class="form-control single-input" required>
                        <option value=""> - Penghasilan atau pengeluaran per bulan - </option>
                        <?php $__currentLoopData = $options->where('tag', 'penghasilan')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="input-group-icon mt-10">
                    <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                    <select name="kepemilikan_tanah" class="form-control single-input" required>
                        <option value=""> - Status kepemilikan tanah - </option>
                        <?php $__currentLoopData = $options->where('tag', 'kepemilikan_tanah')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="input-group-icon mt-10">
                    <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                    <select name="kepemilikan_rumah" class="form-control single-input" required>
                        <option value=""> - Status kepemilikan rumah - </option>
                        <?php $__currentLoopData = $options->where('tag', 'kepemilikan_rumah')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="input-group-icon mt-10">
                    <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                    <select name="aset_rumah" class="form-control single-input" required>
                        <option value=""> - Aset rumah di tempat lain - </option>
                        <?php $__currentLoopData = $options->where('tag', 'aset_rumah')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="input-group-icon mt-10">
                    <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                    <select name="aset_tanah" class="form-control single-input" required>
                        <option value=""> - Aset tanah di tempat lain - </option>
                        <?php $__currentLoopData = $options->where('tag', 'aset_tanah')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="input-group-icon mt-10">
                    <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                    <select name="bantuan_perumahan" class="form-control single-input" required>
                        <option value=""> - Pernah mendapatkan bantuan perumahan - </option>
                        <?php $__currentLoopData = $options->where('tag', 'bantuan_perumahan')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="input-group-icon mt-10">
                    <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                    <select name="lokasi_rumah" class="form-control single-input" required>
                        <option value=""> - Jenis kawasan lokasi rumah yang di tempati - </option>
                        <?php $__currentLoopData = $options->where('tag', 'lokasi_rumah')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mt-30" style="border-bottom: 0.5px solid #efefef;">
                    <h6>II. KONDISI FISIK RUMAH</h6>
                    <h6>A. ASPEK KESELAMATAN</h6>
                </div>
                <div class="row">
                    <div class="col-8">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                            <select name="pondasi" class="form-control single-input" required>
                                <option value=""> - Pondasi - </option>
                                <?php $__currentLoopData = $options->where('tag', 'pondasi')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-images" aria-hidden="true"></i></div>
                            <input type="text" placeholder="Foto" class="single-input foto-trigger" readonly required>
                            <input type="file" name="foto_pondasi[]" class="foto" multiple>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-8">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                            <select name="kolom_balok" class="form-control single-input" required>
                                <option value=""> - Kondisi kolom dan balok - </option>
                                <?php $__currentLoopData = $options->where('tag', 'kolom_balok')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-images" aria-hidden="true"></i></div>
                            <input type="text" placeholder="Foto" class="single-input foto-trigger" readonly required>
                            <input type="file" name="foto_kolom_balok[]" class="foto" multiple>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-8">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                            <select name="konstruksi_atap" class="form-control single-input" required>
                                <option value=""> - Kondisi konstruksi atap - </option>
                                <?php $__currentLoopData = $options->where('tag', 'konstruksi_atap')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-images" aria-hidden="true"></i></div>
                            <input type="text" placeholder="Foto" class="single-input foto-trigger" readonly required>
                            <input type="file" name="foto_konstruksi_atap[]" class="foto" multiple>
                        </div>
                    </div>
                </div>
                <div class="mt-30" style="border-bottom: 0.5px solid #efefef;">
                    <h6>B. ASPEK KESEHATAN</h6>
                </div>
                <div class="row">
                    <div class="col-8">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                            <select name="jendela" class="form-control single-input" required>
                                <option value=""> - Jendela/Lubang Cahaya - </option>
                                <?php $__currentLoopData = $options->where('tag', 'jendela')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-images" aria-hidden="true"></i></div>
                            <input type="text" placeholder="Foto" class="single-input foto-trigger" readonly required>
                            <input type="file" name="foto_jendela[]" class="foto" multiple>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-8">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                            <select name="ventilasi" class="form-control single-input" required>
                                <option value=""> - Ventilasi - </option>
                                <?php $__currentLoopData = $options->where('tag', 'ventilasi')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-images" aria-hidden="true"></i></div>
                            <input type="text" placeholder="Foto" class="single-input foto-trigger" readonly required>
                            <input type="file" name="foto_ventilasi[]" class="foto" multiple>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-8">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                            <select name="kamar_mandi" class="form-control single-input" required>
                                <option value=""> - Kepemilikan kamar mandi dan jamban - </option>
                                <?php $__currentLoopData = $options->where('tag', 'kamar_mandi')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-images" aria-hidden="true"></i></div>
                            <input type="text" placeholder="Foto" class="single-input foto-trigger" readonly required>
                            <input type="file" name="foto_kamar_mandi[]" class="foto" multiple>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-8">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                            <select name="jarak_air" class="form-control single-input" required>
                                <option value=""> - Jarak sumber air minum ke TPA tinja - </option>
                                <?php $__currentLoopData = $options->where('tag', 'jarak_air')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-images" aria-hidden="true"></i></div>
                            <input type="text" placeholder="Foto" class="single-input foto-trigger" readonly required>
                            <input type="file" name="foto_jarak_air[]" class="foto" multiple>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-8">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                            <select name="sumber_air" class="form-control single-input" required>
                                <option value=""> - Sumber air minum - </option>
                                <?php $__currentLoopData = $options->where('tag', 'sumber_air')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-images" aria-hidden="true"></i></div>
                            <input type="text" placeholder="Foto" class="single-input foto-trigger" readonly required>
                            <input type="file" name="foto_sumber_air[]" class="foto" multiple>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-8">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                            <select name="sumber_listrik" class="form-control single-input" required>
                                <option value=""> - Sumber Listrik - </option>
                                <?php $__currentLoopData = $options->where('tag', 'sumber_listrik')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-images" aria-hidden="true"></i></div>
                            <input type="text" placeholder="Foto" class="single-input foto-trigger" readonly required>
                            <input type="file" name="foto_sumber_listrik[]" class="foto" multiple>
                        </div>
                    </div>
                </div>
                <div class="mt-30" style="border-bottom: 0.5px solid #efefef;">
                    <h6>C. ASPEK PERSYARATAN LUAS DAN KEBUTUHAN RUANG</h6>
                </div>
                <div class="mt-10">
                    <input type="text" name="luas_rumah" placeholder="Luas Rumah (per meter persegi)" class="single-input" required>
                </div>
                <div class="mt-10">
                    <input type="number" min="1" name="jumlah_penghuni" placeholder="Jumlah Penghuni (Orang)" class="single-input" required>
                </div>
                <div class="mt-30" style="border-bottom: 0.5px solid #efefef;">
                    <h6>D. ASPEK KOMPONEN BAHAN BANGUNAN SESUAI KONTEKS LOKAL</h6>
                </div>
                <div class="row">
                    <div class="col-8">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                            <select name="material_atap" class="form-control single-input" required>
                                <option value=""> - Material atap terluas - </option>
                                <?php $__currentLoopData = $options->where('tag', 'material_atap')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-images" aria-hidden="true"></i></div>
                            <input type="text" placeholder="Foto" class="single-input foto-trigger" readonly required>
                            <input type="file" name="foto_material_atap[]" class="foto" multiple>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-8">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                            <select name="kondisi_atap" class="form-control single-input" required>
                                <option value=""> - Kondisi atap - </option>
                                <?php $__currentLoopData = $options->where('tag', 'kondisi_atap')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-images" aria-hidden="true"></i></div>
                            <input type="text" placeholder="Foto" class="single-input foto-trigger" readonly required>
                            <input type="file" name="foto_kondisi_atap[]" class="foto" multiple>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-8">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                            <select name="material_dinding" class="form-control single-input" required>
                                <option value=""> - Material dinding terluas - </option>
                                <?php $__currentLoopData = $options->where('tag', 'material_dinding')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-images" aria-hidden="true"></i></div>
                            <input type="text" placeholder="Foto" class="single-input foto-trigger" readonly required>
                            <input type="file" name="foto_material_dinding[]" class="foto" multiple>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-8">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                            <select name="kondisi_dinding" class="form-control single-input" required>
                                <option value=""> - Kondisi Dinding - </option>
                                <?php $__currentLoopData = $options->where('tag', 'kondisi_dinding')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-images" aria-hidden="true"></i></div>
                            <input type="text" placeholder="Foto" class="single-input foto-trigger" readonly required>
                            <input type="file" name="foto_kondisi_dinding[]" class="foto" multiple>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-8">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                            <select name="material_lantai" class="form-control single-input" required>
                                <option value=""> - Material lantai terluas - </option>
                                <?php $__currentLoopData = $options->where('tag', 'material_lantai')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-images" aria-hidden="true"></i></div>
                            <input type="text" placeholder="Foto" class="single-input foto-trigger" readonly required>
                            <input type="file" name="foto_material_lantai[]" class="foto" multiple>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-8">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-caret-right" aria-hidden="true"></i></div>
                            <select name="kondisi_lantai" class="form-control single-input" required>
                                <option value=""> - Kondisi lantai - </option>
                                <?php $__currentLoopData = $options->where('tag', 'kondisi_lantai')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="input-group-icon mt-10">
                            <div class="icon"><i class="fa fa-images" aria-hidden="true"></i></div>
                            <input type="text" placeholder="Foto" class="single-input foto-trigger" readonly required>
                            <input type="file" name="foto_kondisi_lantai[]" class="foto" multiple>
                        </div>
                    </div>
                </div>
                <div class="mt-10">
                    <button type="submit" class="genric-btn info radius">Submit</button>
                </div>
            </form>
          </div>  
        </div>
    </div>


    <script src="<?php echo e(asset('assets/js/vendor/jquery-1.12.4.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script>
        $(function() {
            //input file function
            $('.foto-trigger').click(function() {
                element = $(this);
                fotoInput = element.next();

                //pop upload dialog
                fotoInput.click();

                fotoInput.change(function() {
                    files = $(this).get(0).files;
                    if(files.length > 0){
                        element.val(files.length + ' Foto');
                    }else{
                        element.val('');
                    }
                    fotoInput.off('change');
                });
            });

            // $('button').click(function(e) {
            //     e.preventDefault();
            //     if(confirm('Proses upload foto memerlukan waktu beberapa menit tergantung jumlah foto, jangan refresh atau tutup browser selama proses berlangsung. Lanjutkan ?')){
            //         $('form').submit();
            //     }
            // });

        });
    </script>
</body>
</html><?php /**PATH C:\xampp\htdocs\gis_bontang_web_laravel_8\resources\views/public/form.blade.php ENDPATH**/ ?>