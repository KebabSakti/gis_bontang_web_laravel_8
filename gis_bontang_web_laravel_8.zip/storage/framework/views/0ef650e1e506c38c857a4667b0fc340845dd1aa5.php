<div class="grid">
    <div class="grid-sizer"></div>
    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="grid-item">
            <a href="<?php echo e(asset('foto/'.$item->image)); ?>" class="img-pop-up">
                <img src="<?php echo e(asset('foto/'.$item->image)); ?>">
            </a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\xampp\htdocs\gis_bontang_web_laravel_8\resources\views/admin/formulir/foto.blade.php ENDPATH**/ ?>